package com.hryzx.movieapp.data;

public class CastEntity {
    private String mCastId;
    private Integer mPosition;
    private String imagePath;

    public CastEntity(String mCastId, Integer mPosition, String imagePath) {
        this.mCastId = mCastId;
        this.mPosition = mPosition;
        this.imagePath = imagePath;
    }

    public String getmCastId() {
        return mCastId;
    }

    public void setmCastId(String mCastId) {
        this.mCastId = mCastId;
    }

    public Integer getmPosition() {
        return mPosition;
    }

    public void setmPosition(Integer mPosition) {
        this.mPosition = mPosition;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setImagePath(String imagePath) {
        this.imagePath = imagePath;
    }
}